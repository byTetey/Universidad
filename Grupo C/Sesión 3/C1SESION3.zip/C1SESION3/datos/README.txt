
Afonso y Gala son pseudonimos utilizados para locutores anónimos del "Crowdsourced high-quality Galician speech data set"
de Google (http://openslr.org/77/), distribuido según licencia "https://creativecommons.org/licenses/by-sa/4.0/".

Los archivos de Afonso y Gala aquí contenidos se corresponden con versiones recortadas y remuestreadas de los archivos
"gam_09334_01614520473.wav" y "glf_09334_01676118494.wav" de dicho conjunto de datos.


